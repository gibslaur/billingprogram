package restaurantBillingProgram;

public class Billing {
			
			public static void generateT1() {
				
				// Arrays of menu items and prices
				String[] items = {"Salad", "Sandwich", "Soup", "Pasta", "Soda", "Water"};
				double[] cost = {7.0, 7.5, 6.0, 7.5, 1.5, 0.0};
				
			    // Create table object
				Table t1 = new Table();
				t1.setTableNum(1);
				// addOrder items and quantity from corresponding arrays
				t1.addOrder("Sandwich", 2, items, cost);
				t1.addOrder("Salad", 1, items, cost);
				t1.addOrder("Soup", 1, items, cost);
				t1.addOrder("Water", 2, items, cost);
				// Display bill
				System.out.println("Table #" + t1.getTableNum());
				System.out.println("Item \t Quantity");
				System.out.println("------------------");
				t1.getOrder();
				System.out.println("------------------");
				System.out.print("Total cost: $");
				System.out.printf("%.2f", t1.getTotal());
				System.out.println("\n");
			}
			
			public static void generateT2() {
				
				// Arrays of menu items and prices
				String[] items = {"Salad", "Sandwich", "Soup", "Pasta", "Soda", "Water"};
				double[] cost = {7.0, 7.5, 6.0, 7.5, 1.5, 0.0};
							
				Table t2 = new Table();
				t2.setTableNum(2);
				// addOrder items and quantity from corresponding arrays
			    t2.addOrder("Soup", 1, items, cost);
			    t2.addOrder("Sandwich", 2, items, cost);
				t2.addOrder("Soda", 1, items, cost);
				t2.addOrder("Water", 1, items, cost);
				// Display bill
			    System.out.println("Table #" + t2.getTableNum());
			    System.out.println("Item \t Quantity");
			    System.out.println("------------------");
			    t2.getOrder();
			    System.out.println("------------------");
				System.out.print("Total cost: $");
				System.out.printf("%.2f", t2.getTotal());
				System.out.println("\n");
			}
			
				public static void generateT3() {
				
				// Arrays of menu items and prices
				String[] items = {"Salad", "Sandwich", "Soup", "Pasta", "Soda", "Water"};
				double[] cost = {7.0, 7.5, 6.0, 7.5, 1.5, 0.0};
							
				Table t3 = new Table();
				t3.setTableNum(3);
				// addOrder items and quantity from corresponding arrays
			    t3.addOrder("Pasta", 1, items, cost);
			    t3.addOrder("Salad", 1, items, cost);
				t3.addOrder("Soda", 1, items, cost);
				// Display bill
			    System.out.println("Table #" + t3.getTableNum());
			    System.out.println("Item \t Quantity");
			    System.out.println("------------------");
			    t3.getOrder();
			    System.out.println("------------------");
				System.out.print("Total cost: $");
				System.out.printf("%.2f", t3.getTotal());
				System.out.println("\n");
			}
}
