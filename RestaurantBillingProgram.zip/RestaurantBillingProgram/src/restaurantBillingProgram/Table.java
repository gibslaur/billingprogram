package restaurantBillingProgram;
import java.util.ArrayList;

public class Table {
	
	// Arrays
	private ArrayList<String> orderedFood;
	private ArrayList<Integer> orderedQuantity;
	
	// Table constructor
	public Table() {
		orderedFood = new ArrayList<String>();
	    orderedQuantity = new ArrayList<Integer>();
	 }
	
	// Initialize total cost
	private double totalCost = 0;
	
	// Table number
	private int tableNum;
	
	// Accessor method for table number
	public int getTableNum() {
		return tableNum;
	}
	
	// Mutator method for table number
	public void setTableNum(int tableNum) {
		this.tableNum = tableNum;
	}

	
	// Accessor method for total cost of order
	public double getTotal() {
		return totalCost;
	}
	
	
	// Method to update orderedFood, orderedQuantity, and totalCost with order
	 public void addOrder(String item, int quantity, String[] items, double[] cost) {
	 orderedFood.add(item);
	 orderedQuantity.add(quantity);
	 for (int i = 0; i < items.length; i++) {
		 if (item.equals(items[i])) {   
			 // Add cost to total cost
			 totalCost += quantity * cost[i];
		 } 
	 }
	 }
	 
	 // Method to get ordered items and quantity
	 public void getOrder() {
	 for (int i = 0; i < orderedFood.size(); i++) {
		 System.out.printf("%-8s", orderedFood.get(i));
		 System.out.printf("%8s\n", orderedQuantity.get(i)); 
		 // plus individual item cost?...
	  }
	 }
	 
}
